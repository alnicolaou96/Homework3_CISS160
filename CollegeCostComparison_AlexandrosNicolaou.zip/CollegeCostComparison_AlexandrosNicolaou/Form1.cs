﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeCostComparison_AlexandrosNicolaou
//Author: Alexandros Nicolaou
//ID: 592067
//Date:09-23-20
//This program will calculate total costs of a two colleges and display them
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double gasTotalOne = 0;
        double gasTotalTwo = 0;
        double totalOne = 0;
        double totalTwo = 0;

        private void CollegeNameOne_TextChanged(object sender, EventArgs e)
        {

        }

        private void CollegeNameTwo_TextChanged(object sender, EventArgs e)
        {

        }

        private void TripNumOne_TextChanged(object sender, EventArgs e)
        {

        }

        private void TripNumTwo_TextChanged(object sender, EventArgs e)
        {

        }

        private void GasFeeOne_TextChanged(object sender, EventArgs e)
        {

        }

        private void GasFeeTwo_TextChanged(object sender, EventArgs e)
        {

        }

        private void AppFeeOne_TextChanged(object sender, EventArgs e)
        {

        }

        private void AppFeeTwo_TextChanged(object sender, EventArgs e)
        {

        }

        private void TuitionOne_TextChanged(object sender, EventArgs e)
        {

        }

        private void TuitionTwo_TextChanged(object sender, EventArgs e)
        {

        }

        private void RoomBoardOne_TextChanged(object sender, EventArgs e)
        {

        }

        private void RoomBoardTwo_TextChanged(object sender, EventArgs e)
        {

        }

        private void CollegeOneLabel_Click(object sender, EventArgs e)
        {

        }

        private void CollegeTwoLabel_Click(object sender, EventArgs e)
        {

        }

        private void GasTotalOne_Click(object sender, EventArgs e)
        {

        }

        private void GasTotalTwo_Click(object sender, EventArgs e)
        {

        }

        private void TotalOne_Click(object sender, EventArgs e)
        {

        }

        private void TotalTwo_Click(object sender, EventArgs e)
        {

        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            CollegeOneLabel.Text = CollegeNameOne.Text; //changes labels to college name
            CollegeTwoLabel.Text = CollegeNameTwo.Text;

            gasTotalOne = (Convert.ToDouble(GasFeeOne.Text) * Convert.ToDouble(TripNumOne.Text)) * 2.5;// calculates gas usage per year
            gasTotalTwo = (Convert.ToDouble(GasFeeTwo.Text) * Convert.ToDouble(TripNumTwo.Text)) * 2.5;

            totalOne = gasTotalOne + (Convert.ToDouble(TuitionOne.Text) * 4) + (Convert.ToDouble(RoomBoardOne.Text) * 4) + Convert.ToDouble(AppFeeOne.Text);//total cost for 4 years calculations
            totalTwo = gasTotalTwo + (Convert.ToDouble(TuitionTwo.Text) * 4) + (Convert.ToDouble(RoomBoardTwo.Text) * 4) + Convert.ToDouble(AppFeeTwo.Text);

            GasTotalOne.Text = Convert.ToString(gasTotalOne);//displays costs for gas
            GasTotalTwo.Text = Convert.ToString(gasTotalTwo);

            TotalOne.Text = Convert.ToString(totalOne);//displays total costs
            TotalTwo.Text = Convert.ToString(totalTwo);
        }
    }
}
