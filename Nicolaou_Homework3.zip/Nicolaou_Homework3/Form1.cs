﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


//Author: Alexandros Nicolaou
//ID:592067
//Date:9*22
//Calculate tax 
namespace Nicolaou_Homework3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double salesInput = 0; //variable for users input
        double lorainTax = 0.0625; //tax for lorain
        double tax; //variable for tax of user input
        double total; //user input plus tax

        private void Sales_TextChanged(object sender, EventArgs e)
        {

        }

        private void Tax_TextChanged(object sender, EventArgs e)
        {

        }

        private void Total_TextChanged(object sender, EventArgs e)
        {

        }

        private void Calculate_Click(object sender, EventArgs e)
        {
            salesInput = Convert.ToDouble(Sales.Text);
            tax = salesInput * lorainTax;
            total = salesInput + tax;

            Tax.Text = Convert.ToString("$"+(Math.Round(tax,2)));// convert double into a string and then rounds it to 2 decimal places and change text box text
            Total.Text = Convert.ToString("$"+(Math.Round(total,2)));

        }

        private void Clear_Click(object sender, EventArgs e)
        {
            Tax.Text = "";
            Sales.Text = "";
            Total.Text = "";
        }
    }
}
