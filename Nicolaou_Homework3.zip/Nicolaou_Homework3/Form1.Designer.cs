﻿namespace Nicolaou_Homework3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Sales = new System.Windows.Forms.TextBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.Tax = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.TextBox();
            this.Calculate = new System.Windows.Forms.Button();
            this.Clear = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "enter sales amount";
            // 
            // Sales
            // 
            this.Sales.Location = new System.Drawing.Point(54, 77);
            this.Sales.Name = "Sales";
            this.Sales.Size = new System.Drawing.Size(100, 22);
            this.Sales.TabIndex = 1;
            this.Sales.TextChanged += new System.EventHandler(this.Sales_TextChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(43, 112);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(35, 17);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Tax:";
            // 
            // Tax
            // 
            this.Tax.Location = new System.Drawing.Point(60, 156);
            this.Tax.Name = "Tax";
            this.Tax.Size = new System.Drawing.Size(100, 22);
            this.Tax.TabIndex = 3;
            this.Tax.TextChanged += new System.EventHandler(this.Tax_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Total:";
            // 
            // Total
            // 
            this.Total.Location = new System.Drawing.Point(69, 272);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(100, 22);
            this.Total.TabIndex = 5;
            this.Total.TextChanged += new System.EventHandler(this.Total_TextChanged);
            // 
            // Calculate
            // 
            this.Calculate.Location = new System.Drawing.Point(227, 82);
            this.Calculate.Name = "Calculate";
            this.Calculate.Size = new System.Drawing.Size(88, 23);
            this.Calculate.TabIndex = 6;
            this.Calculate.Text = "Calculate";
            this.Calculate.UseVisualStyleBackColor = true;
            this.Calculate.Click += new System.EventHandler(this.Calculate_Click);
            // 
            // Clear
            // 
            this.Clear.Location = new System.Drawing.Point(240, 134);
            this.Clear.Name = "Clear";
            this.Clear.Size = new System.Drawing.Size(75, 23);
            this.Clear.TabIndex = 7;
            this.Clear.Text = "Clear";
            this.Clear.UseVisualStyleBackColor = true;
            this.Clear.Click += new System.EventHandler(this.Clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Clear);
            this.Controls.Add(this.Calculate);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Tax);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Sales);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Sales;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.TextBox Tax;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Total;
        private System.Windows.Forms.Button Calculate;
        private System.Windows.Forms.Button Clear;
    }
}

